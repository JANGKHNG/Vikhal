import { db } from "./index";
import * as schema from "@shared/schema";

async function seed() {
  try {
    console.log("Starting to seed the database...");

    // Seed slider images
    const sliderImagesData = [
      {
        imageUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4",
        alt: "Mountain landscape photography",
        order: 1,
        active: true
      },
      {
        imageUrl: "https://images.unsplash.com/photo-1519011985187-444d62641929",
        alt: "Portrait photography",
        order: 2,
        active: true
      },
      {
        imageUrl: "https://images.unsplash.com/photo-1533090161767-e6ffed986c88",
        alt: "Architecture photography",
        order: 3,
        active: true
      }
    ];
    
    console.log("Seeding slider images...");
    
    for (const image of sliderImagesData) {
      // Check if image already exists with the same URL
      const existingImage = await db.query.sliderImages.findFirst({
        where: (sliderImages, { eq }) => eq(sliderImages.imageUrl, image.imageUrl)
      });
      
      if (!existingImage) {
        const validated = schema.sliderImageSchema.parse(image);
        await db.insert(schema.sliderImages).values(validated);
        console.log(`Added slider image: ${image.alt}`);
      } else {
        console.log(`Slider image already exists: ${image.alt}`);
      }
    }

    // Seed portfolio items
    const portfolioItemsData = [
      {
        title: "Wedding Bliss",
        location: "Paris, France",
        category: "weddings",
        imageUrl: "https://images.unsplash.com/photo-1511285560929-80b456fea0bc",
        featured: true
      },
      {
        title: "Rustic Romance",
        location: "Tuscany, Italy",
        category: "weddings",
        imageUrl: "https://images.unsplash.com/photo-1519741497674-611481863552",
        featured: false
      },
      {
        title: "Mountain Majesty",
        location: "Banff, Canada",
        category: "nature",
        imageUrl: "https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05",
        featured: true
      },
      {
        title: "Desert Dreams",
        location: "Dubai, UAE",
        category: "nature",
        imageUrl: "https://images.unsplash.com/photo-1505144808419-1957a94ca61e",
        featured: false
      },
      {
        title: "Natural Beauty",
        location: "London Studio",
        category: "portraits",
        imageUrl: "https://images.unsplash.com/photo-1531123897727-8f129e1688ce",
        featured: true
      },
      {
        title: "Character Study",
        location: "New York City",
        category: "portraits",
        imageUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d",
        featured: false
      },
      {
        title: "Urban Geometry",
        location: "Tokyo, Japan",
        category: "architecture",
        imageUrl: "https://images.unsplash.com/photo-1487958449943-2429e8be8625",
        featured: true
      },
      {
        title: "Heritage Lines",
        location: "Rome, Italy",
        category: "architecture",
        imageUrl: "https://images.unsplash.com/photo-1518005020951-eccb494ad742",
        featured: false
      }
    ];
    
    console.log("Seeding portfolio items...");
    
    for (const item of portfolioItemsData) {
      // Check if item already exists with the same title and location
      const existingItem = await db.query.portfolioItems.findFirst({
        where: (portfolioItems, { and, eq }) => and(
          eq(portfolioItems.title, item.title),
          eq(portfolioItems.location, item.location)
        )
      });
      
      if (!existingItem) {
        const validated = schema.portfolioItemSchema.parse(item);
        await db.insert(schema.portfolioItems).values(validated);
        console.log(`Added portfolio item: ${item.title} - ${item.location}`);
      } else {
        console.log(`Portfolio item already exists: ${item.title} - ${item.location}`);
      }
    }

    // Seed testimonials
    const testimonialsData = [
      {
        name: "Sarah & Michael",
        role: "Wedding Clients",
        message: "Vikal Photography captured our wedding day perfectly. Every emotion, every special moment was documented beautifully. We couldn't be happier with the results!",
        imageUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330",
        active: true
      },
      {
        name: "David Chen",
        role: "Corporate Client",
        message: "The corporate portraits Vikal Photography did for our team were exceptional. Professional, efficient, and the results exceeded our expectations.",
        imageUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d",
        active: true
      },
      {
        name: "Elena Rodriguez",
        role: "Interior Designer",
        message: "As an interior designer, I needed precise architectural photography. Vikal not only delivered technically perfect images but brought artistic vision to highlight the best aspects of my designs.",
        imageUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2",
        active: true
      }
    ];
    
    console.log("Seeding testimonials...");
    
    for (const testimonial of testimonialsData) {
      // Check if testimonial already exists with the same name and role
      const existingTestimonial = await db.query.testimonials.findFirst({
        where: (testimonials, { and, eq }) => and(
          eq(testimonials.name, testimonial.name),
          eq(testimonials.role, testimonial.role)
        )
      });
      
      if (!existingTestimonial) {
        const validated = schema.testimonialSchema.parse(testimonial);
        await db.insert(schema.testimonials).values(validated);
        console.log(`Added testimonial from: ${testimonial.name}`);
      } else {
        console.log(`Testimonial already exists from: ${testimonial.name}`);
      }
    }

    console.log("Database seeding completed successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

seed();
