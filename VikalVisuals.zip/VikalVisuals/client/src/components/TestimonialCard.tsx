interface TestimonialCardProps {
  name: string;
  role: string;
  message: string;
  imageUrl: string;
}

const TestimonialCard = ({ name, role, message, imageUrl }: TestimonialCardProps) => {
  return (
    <div className="bg-white p-8 rounded-sm shadow-md fade-in">
      <div className="text-[#D4AF37] mb-4">
        <i className="fas fa-star"></i>
        <i className="fas fa-star"></i>
        <i className="fas fa-star"></i>
        <i className="fas fa-star"></i>
        <i className="fas fa-star"></i>
      </div>
      <p className="text-gray-600 mb-6 italic">"{message}"</p>
      <div className="flex items-center">
        <div className="w-12 h-12 bg-gray-300 rounded-full overflow-hidden mr-4">
          <img src={imageUrl} alt={name} className="w-full h-full object-cover" />
        </div>
        <div>
          <h4 className="font-semibold">{name}</h4>
          <p className="text-sm text-gray-500">{role}</p>
        </div>
      </div>
    </div>
  );
};

export default TestimonialCard;
