import { cn } from '@/lib/utils';

interface ParallaxSectionProps {
  backgroundImage: string;
  children: React.ReactNode;
  className?: string;
}

const ParallaxSection = ({ backgroundImage, children, className }: ParallaxSectionProps) => {
  return (
    <section 
      className={cn(
        "h-96 parallax flex items-center justify-center fade-in",
        className
      )}
      style={{ backgroundImage: `url('${backgroundImage}')` }}
    >
      {children}
    </section>
  );
};

export default ParallaxSection;
