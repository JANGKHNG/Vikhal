import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";

const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  const closeMenu = () => {
    setMenuOpen(false);
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "bg-black shadow-md" : "bg-white"
      }`}
    >
      <div className="container mx-auto px-4 md:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <Link href="/" className={`text-2xl md:text-3xl font-playfair font-semibold tracking-wider ${scrolled ? 'text-white' : 'text-black'}`}>
            Vikal Photography
          </Link>

          <div className="hidden md:flex space-x-8 items-center">
            <Link href="/" className={`${scrolled ? 'text-white' : 'text-black'} hover:text-[#D4AF37] transition duration-300 ${location === '/' ? 'text-[#D4AF37]' : ''}`}>
              Home
            </Link>
            <Link href="/about" className={`${scrolled ? 'text-white' : 'text-black'} hover:text-[#D4AF37] transition duration-300 ${location === '/about' ? 'text-[#D4AF37]' : ''}`}>
              About
            </Link>
            <Link href="/portfolio" className={`${scrolled ? 'text-white' : 'text-black'} hover:text-[#D4AF37] transition duration-300 ${location === '/portfolio' ? 'text-[#D4AF37]' : ''}`}>
              Portfolio
            </Link>
            <Link href="/contact" className={`${scrolled ? 'text-white' : 'text-black'} hover:text-[#D4AF37] transition duration-300 ${location === '/contact' ? 'text-[#D4AF37]' : ''}`}>
              Contact
            </Link>
            <Link href="/contact">
              <Button variant="gold" size="lg" className="ml-4">
                Book a Session
              </Button>
            </Link>
          </div>

          <button
            className={`md:hidden ${scrolled ? 'text-white' : 'text-black'} focus:outline-none`}
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            <i className="fas fa-bars text-xl"></i>
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden bg-black bg-opacity-95 overflow-hidden transition-all duration-500 ${
          menuOpen ? "h-[300px]" : "h-0"
        }`}
      >
        <div className="container mx-auto px-4 py-6 flex flex-col space-y-6">
          <Link href="/" className={`text-black hover:text-[#D4AF37] text-lg transition duration-300 ${location === '/' ? 'text-[#D4AF37]' : ''}`} onClick={closeMenu}>
            Home
          </Link>
          <Link href="/about" className={`text-black hover:text-[#D4AF37] text-lg transition duration-300 ${location === '/about' ? 'text-[#D4AF37]' : ''}`} onClick={closeMenu}>
            About
          </Link>
          <Link href="/portfolio" className={`text-black hover:text-[#D4AF37] text-lg transition duration-300 ${location === '/portfolio' ? 'text-[#D4AF37]' : ''}`} onClick={closeMenu}>
            Portfolio
          </Link>
          <Link href="/contact" className={`text-black hover:text-[#D4AF37] text-lg transition duration-300 ${location === '/contact' ? 'text-[#D4AF37]' : ''}`} onClick={closeMenu}>
            Contact
          </Link>
          <Link href="/contact" onClick={closeMenu} className="w-full">
            <Button variant="gold" className="w-full">
              Book a Session
            </Button>
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;