import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { portfolioCategories } from '@/lib/utils';
import { Button } from '@/components/ui/button';

type PortfolioItem = {
  id: number;
  imageUrl: string;
  title: string;
  location: string;
  category: string;
};

const PortfolioGallery = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  
  const { data: portfolioItems = [], isLoading } = useQuery({
    queryKey: ['/api/portfolio'],
    initialData: [] as PortfolioItem[],
  });
  
  const filteredItems = portfolioItems.filter(
    (item) => activeCategory === 'all' || item.category === activeCategory
  );

  const handleCategoryChange = (category: string) => {
    setActiveCategory(category);
  };

  return (
    <div>
      {/* Portfolio Categories */}
      <div className="flex flex-wrap justify-center gap-4 mb-12 fade-in">
        {portfolioCategories.map((category) => (
          <Button
            key={category.id}
            onClick={() => handleCategoryChange(category.id)}
            variant={activeCategory === category.id ? "black" : "secondary"}
            className="px-6 py-2 rounded-sm transition duration-300"
          >
            {category.name}
          </Button>
        ))}
      </div>
      
      {/* Gallery Grid */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-80 bg-gray-200 animate-pulse rounded-sm"></div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <div key={item.id} className="gallery-item rounded-sm overflow-hidden shadow-md h-80 fade-in">
              <img 
                src={item.imageUrl} 
                alt={item.title} 
                className="w-full h-full object-cover"
              />
              <div className="gallery-overlay flex flex-col justify-center items-center">
                <h3 className="text-xl font-playfair text-white mb-2">{item.title}</h3>
                <p className="text-[#D4AF37]">{item.location}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default PortfolioGallery;
