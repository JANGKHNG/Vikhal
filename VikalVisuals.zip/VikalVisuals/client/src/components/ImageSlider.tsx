import { useEffect, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { cn } from '@/lib/utils';

type Slide = {
  id: number;
  imageUrl: string;
  alt: string;
};

const ImageSlider = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  
  const { data: slides = [], isLoading } = useQuery({
    queryKey: ['/api/slides'],
    initialData: [] as Slide[],
  });

  useEffect(() => {
    if (slides.length === 0) return;
    
    const interval = setInterval(() => {
      setActiveIndex((current) => (current + 1) % slides.length);
    }, 5000);
    
    return () => clearInterval(interval);
  }, [slides.length]);

  if (isLoading || slides.length === 0) {
    return (
      <div className="slider-container bg-gray-800 animate-pulse">
        <div className="h-full w-full"></div>
      </div>
    );
  }

  return (
    <div className="slider-container">
      {slides.map((slide, index) => (
        <div
          key={slide.id}
          className={cn(
            "absolute inset-0 transition-opacity duration-1000",
            index === activeIndex ? "opacity-100" : "opacity-0"
          )}
        >
          <img
            src={slide.imageUrl}
            alt={slide.alt}
            className="w-full h-full object-cover"
          />
        </div>
      ))}
      
      <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
        {slides.map((_, index) => (
          <button
            key={index}
            className={cn(
              "w-3 h-3 rounded-full transition-all",
              index === activeIndex ? "bg-[#D4AF37]" : "bg-white bg-opacity-50"
            )}
            onClick={() => setActiveIndex(index)}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
};

export default ImageSlider;
