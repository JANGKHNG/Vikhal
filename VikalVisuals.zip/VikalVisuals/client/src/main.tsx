import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { useEffect } from "react";
import { animateElements } from "./lib/utils";

// Initialize animation observer on mount
function AppWithAnimations() {
  useEffect(() => {
    // Run once on initial load
    animateElements();
    
    // Add scroll event listener for animations
    window.addEventListener('scroll', animateElements);
    
    // Cleanup
    return () => {
      window.removeEventListener('scroll', animateElements);
    };
  }, []);
  
  return <App />;
}

createRoot(document.getElementById("root")!).render(<AppWithAnimations />);
