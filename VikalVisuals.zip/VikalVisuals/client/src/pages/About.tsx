import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const About = () => {
  return (
    <>
      {/* Page Header - Empty space for fixed navbar */}
      <div className="h-20"></div>
      
      {/* About Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-8 lg:px-16">
          <div className="text-center mb-16 fade-in">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-4">
              About Vikal Photography
            </h2>
            <div className="w-24 h-1 bg-[#D4AF37] mx-auto"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="fade-in">
              <img 
                src="https://images.unsplash.com/photo-1587614382346-4ec70e388b28" 
                alt="Photographer with camera" 
                className="w-full h-auto rounded-sm shadow-lg"
              />
            </div>
            
            <div className="fade-in">
              <h3 className="text-2xl font-playfair font-semibold mb-6">Our Vision & Passion</h3>
              <p className="text-gray-800 mb-6 leading-relaxed">
                Founded with a deep passion for visual storytelling, Vikal Photography has been capturing life's most precious moments for over a decade. Our approach combines technical expertise with artistic vision to create images that transcend ordinary photography.
              </p>
              <p className="text-gray-800 mb-6 leading-relaxed">
                We believe that every moment has its own unique beauty, and our mission is to preserve these fleeting instances in timeless photographs. Whether it's the subtle glance between newlyweds, the majestic grandeur of a landscape, or the authentic emotion in a portrait – we capture the essence that makes each subject special.
              </p>
              <Link href="/contact">
                <Button variant="black">
                  Book a Session
                </Button>
              </Link>
            </div>
          </div>
          
          {/* Stats Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-20 text-center fade-in">
            <div className="p-6 bg-gray-50 rounded-sm shadow-sm">
              <span className="text-4xl font-playfair font-bold text-[#D4AF37]">1200+</span>
              <p className="mt-2 text-gray-600">Photo Sessions</p>
            </div>
            <div className="p-6 bg-gray-50 rounded-sm shadow-sm">
              <span className="text-4xl font-playfair font-bold text-[#D4AF37]">15</span>
              <p className="mt-2 text-gray-600">Years Experience</p>
            </div>
            <div className="p-6 bg-gray-50 rounded-sm shadow-sm">
              <span className="text-4xl font-playfair font-bold text-[#D4AF37]">42</span>
              <p className="mt-2 text-gray-600">Awards Won</p>
            </div>
            <div className="p-6 bg-gray-50 rounded-sm shadow-sm">
              <span className="text-4xl font-playfair font-bold text-[#D4AF37]">96%</span>
              <p className="mt-2 text-gray-600">Client Satisfaction</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Team Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 md:px-8 lg:px-16">
          <div className="text-center mb-16 fade-in">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-4">
              Meet Our Team
            </h2>
            <div className="w-24 h-1 bg-[#D4AF37] mx-auto mb-6"></div>
            <p className="max-w-2xl mx-auto text-gray-600">
              Our talented team of professional photographers brings creativity, passion, and expertise to every project.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 fade-in">
            <div className="bg-white p-6 rounded-sm shadow-sm text-center">
              <div className="mb-4 h-64 overflow-hidden rounded-sm">
                <img 
                  src="https://images.unsplash.com/photo-1568602471122-7832951cc4c5" 
                  alt="Vikal Singh - Lead Photographer" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-playfair font-semibold">Vikal Singh</h3>
              <p className="text-[#D4AF37] mb-2">Lead Photographer & Founder</p>
              <p className="text-gray-600 text-sm">
                With over 15 years of experience, Vikal has developed a unique style that blends emotional storytelling with technical precision.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-sm shadow-sm text-center">
              <div className="mb-4 h-64 overflow-hidden rounded-sm">
                <img 
                  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330" 
                  alt="Maya Patel - Portrait Specialist" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-playfair font-semibold">Maya Patel</h3>
              <p className="text-[#D4AF37] mb-2">Portrait Specialist</p>
              <p className="text-gray-600 text-sm">
                Maya has an exceptional eye for capturing the authentic essence of her subjects, creating portraits that reveal character and emotion.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-sm shadow-sm text-center">
              <div className="mb-4 h-64 overflow-hidden rounded-sm">
                <img 
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d" 
                  alt="Raj Kumar - Landscape Expert" 
                  className="w-full h-full object-cover"
                />
              </div>
              <h3 className="text-xl font-playfair font-semibold">Raj Kumar</h3>
              <p className="text-[#D4AF37] mb-2">Landscape Expert</p>
              <p className="text-gray-600 text-sm">
                Raj's passion for nature and architecture allows him to capture breathtaking landscapes and urban scenes with a unique perspective.
              </p>
            </div>
          </div>
          
          <div className="text-center mt-12 fade-in">
            <Link href="/contact">
              <Button variant="gold" size="lg">
                Work With Our Team
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Our Philosophy Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-8 lg:px-16">
          <div className="max-w-3xl mx-auto fade-in">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-8 text-center">
              Our Philosophy
            </h2>
            
            <div className="space-y-8">
              <div className="flex items-start">
                <div className="w-16 h-16 bg-[#D4AF37] text-white flex items-center justify-center rounded-full mr-6 flex-shrink-0">
                  <i className="fas fa-camera text-2xl"></i>
                </div>
                <div>
                  <h3 className="text-xl font-playfair font-semibold mb-2">Authentic Moments</h3>
                  <p className="text-gray-600">
                    We believe in capturing authentic, unscripted moments that tell your unique story. Our documentary approach allows us to create honest images filled with emotion and meaning.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="w-16 h-16 bg-[#D4AF37] text-white flex items-center justify-center rounded-full mr-6 flex-shrink-0">
                  <i className="fas fa-lightbulb text-2xl"></i>
                </div>
                <div>
                  <h3 className="text-xl font-playfair font-semibold mb-2">Creative Vision</h3>
                  <p className="text-gray-600">
                    Our photographers bring a creative perspective to each project, finding unique angles, compositions, and lighting to elevate ordinary scenes into extraordinary images.
                  </p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="w-16 h-16 bg-[#D4AF37] text-white flex items-center justify-center rounded-full mr-6 flex-shrink-0">
                  <i className="fas fa-heart text-2xl"></i>
                </div>
                <div>
                  <h3 className="text-xl font-playfair font-semibold mb-2">Personalized Experience</h3>
                  <p className="text-gray-600">
                    We take the time to understand your unique vision and preferences. Every photography package is tailored to reflect your personality and meet your specific needs.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default About;
