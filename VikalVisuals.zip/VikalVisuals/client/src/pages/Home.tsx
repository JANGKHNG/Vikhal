import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import ImageSlider from "@/components/ImageSlider";
import ParallaxSection from "@/components/ParallaxSection";
import TestimonialCard from "@/components/TestimonialCard";

const Home = () => {
  const { data: testimonials = [] } = useQuery({
    queryKey: ['/api/testimonials'],
    initialData: [],
  });

  return (
    <>
      {/* Hero Section */}
      <section id="home" className="h-screen relative overflow-hidden">
        {/* Image Slider Component */}
        <ImageSlider />
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
          <div className="text-center px-4 max-w-4xl fade-in">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-playfair font-bold text-white leading-tight mb-6">
              Capturing Moments, Creating Memories
            </h1>
            <p className="text-xl md:text-2xl text-white mb-10 font-light">
              Premium photography services that immortalize your special moments
            </p>
            <Link href="/contact">
              <Button variant="gold" size="xl">
                Book a Session
              </Button>
            </Link>
          </div>
        </div>
        
        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-white text-center">
          <p className="mb-2 text-sm tracking-widest">SCROLL DOWN</p>
          <i className="fas fa-chevron-down animate-bounce"></i>
        </div>
      </section>

      {/* Featured Work Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-8 lg:px-16">
          <div className="text-center mb-16 fade-in">
            <h2 className="section-title">Featured Work</h2>
            <div className="gold-divider"></div>
            <p className="max-w-2xl mx-auto text-gray-600">
              Explore a selection of our most celebrated photography projects
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 fade-in">
            <div className="relative overflow-hidden rounded-sm group">
              <img 
                src="https://images.unsplash.com/photo-1511285560929-80b456fea0bc" 
                alt="Wedding Photography" 
                className="w-full h-80 object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="text-center px-4">
                  <h3 className="text-2xl font-playfair text-white mb-2">Weddings</h3>
                  <Link href="/portfolio">
                    <Button variant="gold" size="sm">
                      View Gallery
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
            
            <div className="relative overflow-hidden rounded-sm group">
              <img 
                src="https://images.unsplash.com/photo-1531123897727-8f129e1688ce" 
                alt="Portrait Photography" 
                className="w-full h-80 object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="text-center px-4">
                  <h3 className="text-2xl font-playfair text-white mb-2">Portraits</h3>
                  <Link href="/portfolio">
                    <Button variant="gold" size="sm">
                      View Gallery
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
            
            <div className="relative overflow-hidden rounded-sm group">
              <img 
                src="https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05" 
                alt="Landscape Photography" 
                className="w-full h-80 object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="text-center px-4">
                  <h3 className="text-2xl font-playfair text-white mb-2">Landscapes</h3>
                  <Link href="/portfolio">
                    <Button variant="gold" size="sm">
                      View Gallery
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
          
          <div className="text-center mt-12 fade-in">
            <Link href="/portfolio">
              <Button variant="black" size="lg">
                View All Work
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Parallax Quote Section */}
      <ParallaxSection backgroundImage="https://images.unsplash.com/photo-1513875528452-39400945934d">
        <div className="text-center px-4 fade-in">
          <h2 className="text-3xl md:text-4xl font-playfair font-bold text-white mb-6">
            "Photography is the art of frozen time"
          </h2>
          <div className="w-24 h-1 bg-[#D4AF37] mx-auto"></div>
        </div>
      </ParallaxSection>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 md:px-8 lg:px-16">
          <div className="text-center mb-16 fade-in">
            <h2 className="section-title">Client Testimonials</h2>
            <div className="gold-divider"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial: any) => (
              <TestimonialCard
                key={testimonial.id}
                name={testimonial.name}
                role={testimonial.role}
                message={testimonial.message}
                imageUrl={testimonial.imageUrl}
              />
            ))}
          </div>
          
          <div className="text-center mt-16 fade-in">
            <Link href="/contact">
              <Button variant="gold" size="xl">
                Book Your Session Today
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Home;
