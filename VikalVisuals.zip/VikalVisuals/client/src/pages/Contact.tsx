import { useEffect } from 'react';
import ContactForm from '@/components/ContactForm';

const Contact = () => {
  return (
    <>
      {/* Page Header - Empty space for fixed navbar */}
      <div className="h-20"></div>

      {/* Contact Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-8 lg:px-16">
          <div className="text-center mb-16 fade-in">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-4">
              Get In Touch
            </h2>
            <div className="w-24 h-1 bg-[#D4AF37] mx-auto mb-6"></div>
            <p className="max-w-2xl mx-auto text-gray-600">
              Have a project in mind or want to inquire about our services? We'd love to hear from you.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form Component */}
            <ContactForm />

            {/* Contact Info */}
            <div className="fade-in">
              <h3 className="text-2xl font-playfair font-semibold mb-6">Contact Information</h3>

              <div className="space-y-4 mb-10">
                <div className="flex items-start">
                  <i className="fas fa-map-marker-alt text-[#D4AF37] mt-1 mr-4 w-6 text-center"></i>
                  <p className="text-gray-700">123 Photography Lane, Creative District<br/>New York, NY 10001</p>
                </div>

                <div className="flex items-center">
                  <i className="fas fa-phone text-[#D4AF37] mr-4 w-6 text-center"></i>
                  <p className="text-gray-700">+1 (555) 123-4567</p>
                </div>

                <div className="flex items-center">
                  <i className="fas fa-envelope text-[#D4AF37] mr-4 w-6 text-center"></i>
                  <p className="text-gray-700">info@vikalphotography.com</p>
                </div>

                <div className="flex items-center">
                  <i className="far fa-clock text-[#D4AF37] mr-4 w-6 text-center"></i>
                  <p className="text-gray-700">Monday-Friday: 9AM-6PM<br/>Saturday: 10AM-4PM</p>
                </div>
              </div>

              <div className="mt-6">
                <h4 className="font-semibold mb-4">Follow Us</h4>
                <div className="flex space-x-4">
                  <a 
                    href="https://instagram.com" 
                    className="w-10 h-10 bg-black text-white flex items-center justify-center rounded-full hover:bg-[#D4AF37] transition duration-300"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <i className="fab fa-instagram"></i>
                  </a>
                  <a 
                    href="https://facebook.com" 
                    className="w-10 h-10 bg-black text-white flex items-center justify-center rounded-full hover:bg-[#D4AF37] transition duration-300"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <i className="fab fa-facebook-f"></i>
                  </a>
                  <a 
                    href="https://pinterest.com" 
                    className="w-10 h-10 bg-black text-white flex items-center justify-center rounded-full hover:bg-[#D4AF37] transition duration-300"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <i className="fab fa-pinterest-p"></i>
                  </a>
                  <a 
                    href="https://twitter.com" 
                    className="w-10 h-10 bg-black text-white flex items-center justify-center rounded-full hover:bg-[#D4AF37] transition duration-300"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <i className="fab fa-twitter"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Contact;