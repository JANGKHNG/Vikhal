import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import PortfolioGallery from "@/components/PortfolioGallery";
import ParallaxSection from "@/components/ParallaxSection";

const Portfolio = () => {
  return (
    <>
      {/* Page Header - Empty space for fixed navbar */}
      <div className="h-20"></div>
      
      {/* Portfolio Header */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-8 lg:px-16">
          <div className="text-center mb-16 fade-in">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-4">
              Our Portfolio
            </h2>
            <div className="w-24 h-1 bg-[#D4AF37] mx-auto mb-6"></div>
            <p className="max-w-2xl mx-auto text-gray-600">
              Explore our diverse collection of photographic work across various genres and locations.
            </p>
          </div>
          
          {/* Portfolio Gallery Component */}
          <PortfolioGallery />
          
          <div className="text-center mt-16 fade-in">
            <Link href="/contact">
              <Button variant="gold" size="xl">
                Book Your Session Today
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Parallax Quote Section */}
      <ParallaxSection backgroundImage="https://images.unsplash.com/photo-1515934751635-c81c6bc9a2d8">
        <div className="text-center px-4 fade-in">
          <h2 className="text-3xl md:text-4xl font-playfair font-bold text-white mb-6">
            "When words become unclear, I shall focus with photographs"
          </h2>
          <div className="w-24 h-1 bg-[#D4AF37] mx-auto"></div>
        </div>
      </ParallaxSection>
      
      {/* Our Process Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 md:px-8 lg:px-16">
          <div className="text-center mb-16 fade-in">
            <h2 className="text-3xl md:text-4xl font-playfair font-bold mb-4">
              Our Creative Process
            </h2>
            <div className="w-24 h-1 bg-[#D4AF37] mx-auto mb-6"></div>
            <p className="max-w-2xl mx-auto text-gray-600">
              From concept to final delivery, we ensure a seamless experience that exceeds your expectations.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 fade-in">
            <div className="text-center">
              <div className="w-20 h-20 bg-[#D4AF37] text-white flex items-center justify-center rounded-full mx-auto mb-4">
                <span className="text-2xl font-bold">01</span>
              </div>
              <h3 className="text-xl font-playfair font-semibold mb-2">Consultation</h3>
              <p className="text-gray-600">
                We begin with a detailed conversation to understand your vision, preferences, and objectives.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-[#D4AF37] text-white flex items-center justify-center rounded-full mx-auto mb-4">
                <span className="text-2xl font-bold">02</span>
              </div>
              <h3 className="text-xl font-playfair font-semibold mb-2">Planning</h3>
              <p className="text-gray-600">
                We develop a customized photography plan including locations, lighting, and creative direction.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-[#D4AF37] text-white flex items-center justify-center rounded-full mx-auto mb-4">
                <span className="text-2xl font-bold">03</span>
              </div>
              <h3 className="text-xl font-playfair font-semibold mb-2">Photo Session</h3>
              <p className="text-gray-600">
                Our photographers execute the vision, capturing authentic moments with technical expertise.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-[#D4AF37] text-white flex items-center justify-center rounded-full mx-auto mb-4">
                <span className="text-2xl font-bold">04</span>
              </div>
              <h3 className="text-xl font-playfair font-semibold mb-2">Delivery</h3>
              <p className="text-gray-600">
                We meticulously edit and deliver your final images in your preferred format with exceptional quality.
              </p>
            </div>
          </div>
          
          <div className="text-center mt-16 fade-in">
            <Link href="/contact">
              <Button variant="black" size="lg">
                Start Your Project Today
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </>
  );
};

export default Portfolio;
