import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function checkVisible(elm: HTMLElement) {
  const rect = elm.getBoundingClientRect();
  const viewHeight = Math.max(document.documentElement.clientHeight, window.innerHeight);
  return !(rect.bottom < 0 || rect.top - viewHeight >= 0);
}

export const animateElements = () => {
  const fadeElements = document.querySelectorAll('.fade-in');
  
  fadeElements.forEach(element => {
    if (checkVisible(element as HTMLElement)) {
      element.classList.add('appear');
    }
  });
};

export const portfolioCategories = [
  { id: 'all', name: 'All' },
  { id: 'weddings', name: 'Weddings' },
  { id: 'nature', name: 'Nature' },
  { id: 'portraits', name: 'Portraits' },
  { id: 'architecture', name: 'Architecture' }
];
