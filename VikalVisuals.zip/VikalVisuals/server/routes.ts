import type { Express } from "express";
import { createServer, type Server } from "http";
import { db } from "@db";
import {
  contactMessages,
  contactMessageSchema,
  portfolioItems,
  testimonials,
  sliderImages,
  newsletterSubscribers,
  newsletterSubscriberSchema
} from "@shared/schema";
import { z } from "zod";
import { eq } from "drizzle-orm";

export async function registerRoutes(app: Express): Promise<Server> {
  // API prefix for all routes
  const apiPrefix = "/api";

  // Get all portfolio items
  app.get(`${apiPrefix}/portfolio`, async (req, res) => {
    try {
      const items = await db.query.portfolioItems.findMany({
        orderBy: (portfolioItems, { desc }) => [desc(portfolioItems.createdAt)]
      });
      
      return res.json(items);
    } catch (error) {
      console.error("Error fetching portfolio items:", error);
      return res.status(500).json({ error: "Failed to fetch portfolio items" });
    }
  });

  // Get all testimonials
  app.get(`${apiPrefix}/testimonials`, async (req, res) => {
    try {
      const allTestimonials = await db.query.testimonials.findMany({
        where: eq(testimonials.active, true),
        orderBy: (testimonials, { desc }) => [desc(testimonials.createdAt)]
      });
      
      return res.json(allTestimonials);
    } catch (error) {
      console.error("Error fetching testimonials:", error);
      return res.status(500).json({ error: "Failed to fetch testimonials" });
    }
  });

  // Get all slider images
  app.get(`${apiPrefix}/slides`, async (req, res) => {
    try {
      const slides = await db.query.sliderImages.findMany({
        where: eq(sliderImages.active, true),
        orderBy: (sliderImages, { asc }) => [asc(sliderImages.order)]
      });
      
      return res.json(slides);
    } catch (error) {
      console.error("Error fetching slider images:", error);
      return res.status(500).json({ error: "Failed to fetch slider images" });
    }
  });

  // Submit contact form
  app.post(`${apiPrefix}/contact`, async (req, res) => {
    try {
      // Validate the request body
      const validatedData = contactMessageSchema.parse(req.body);
      
      // Insert into database
      const [newMessage] = await db.insert(contactMessages)
        .values(validatedData)
        .returning();
      
      return res.status(201).json({
        message: "Contact message sent successfully",
        id: newMessage.id
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: error.errors 
        });
      }
      
      console.error("Error submitting contact form:", error);
      return res.status(500).json({ error: "Failed to submit contact form" });
    }
  });

  // Subscribe to newsletter
  app.post(`${apiPrefix}/newsletter/subscribe`, async (req, res) => {
    try {
      // Validate the request body
      const validatedData = newsletterSubscriberSchema.parse(req.body);
      
      // Check if email already exists
      const existingSubscriber = await db.query.newsletterSubscribers.findFirst({
        where: eq(newsletterSubscribers.email, validatedData.email)
      });
      
      if (existingSubscriber) {
        // If subscriber exists but is inactive, reactivate them
        if (!existingSubscriber.active) {
          await db
            .update(newsletterSubscribers)
            .set({ active: true })
            .where(eq(newsletterSubscribers.email, validatedData.email));
          
          return res.json({ 
            message: "Your subscription has been reactivated" 
          });
        }
        
        // If already active
        return res.json({ 
          message: "You are already subscribed to our newsletter" 
        });
      }
      
      // Insert new subscriber
      const [newSubscriber] = await db
        .insert(newsletterSubscribers)
        .values(validatedData)
        .returning();
      
      return res.status(201).json({ 
        message: "Successfully subscribed to newsletter",
        id: newSubscriber.id
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: "Validation failed", 
          details: error.errors 
        });
      }
      
      console.error("Error subscribing to newsletter:", error);
      return res.status(500).json({ error: "Failed to subscribe to newsletter" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
