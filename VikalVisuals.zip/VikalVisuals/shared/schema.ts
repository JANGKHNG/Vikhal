import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Contact Messages table
export const contactMessages = pgTable("contact_messages", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  service: text("service").notNull(),
  message: text("message").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  read: boolean("read").default(false).notNull(),
});

// Contact message schema for validation
export const contactMessageSchema = createInsertSchema(contactMessages, {
  name: (schema) => schema.min(2, "Name must be at least 2 characters"),
  email: (schema) => schema.email("Must be a valid email address"),
  service: (schema) => schema.min(1, "Please select a service"),
  message: (schema) => schema.min(10, "Message must be at least 10 characters"),
});

// Portfolio Items table
export const portfolioItems = pgTable("portfolio_items", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  location: text("location").notNull(),
  category: text("category").notNull(),
  imageUrl: text("image_url").notNull(),
  featured: boolean("featured").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Portfolio item schema for validation
export const portfolioItemSchema = createInsertSchema(portfolioItems, {
  title: (schema) => schema.min(2, "Title must be at least 2 characters"),
  location: (schema) => schema.min(2, "Location must be at least 2 characters"),
  category: (schema) => schema.min(2, "Category must be at least 2 characters"),
  imageUrl: (schema) => schema.url("Image URL must be a valid URL"),
});

// Testimonials table
export const testimonials = pgTable("testimonials", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  role: text("role").notNull(),
  message: text("message").notNull(),
  imageUrl: text("image_url").notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Testimonial schema for validation
export const testimonialSchema = createInsertSchema(testimonials, {
  name: (schema) => schema.min(2, "Name must be at least 2 characters"),
  role: (schema) => schema.min(2, "Role must be at least 2 characters"),
  message: (schema) => schema.min(10, "Message must be at least 10 characters"),
  imageUrl: (schema) => schema.url("Image URL must be a valid URL"),
});

// Slider Images table
export const sliderImages = pgTable("slider_images", {
  id: serial("id").primaryKey(),
  imageUrl: text("image_url").notNull(),
  alt: text("alt").notNull(),
  order: integer("order").notNull(),
  active: boolean("active").default(true).notNull(),
});

// Slider image schema for validation
export const sliderImageSchema = createInsertSchema(sliderImages, {
  imageUrl: (schema) => schema.url("Image URL must be a valid URL"),
  alt: (schema) => schema.min(2, "Alt text must be at least 2 characters"),
  order: (schema) => schema.int().min(0, "Order must be a positive number"),
});

// Newsletter Subscribers table
export const newsletterSubscribers = pgTable("newsletter_subscribers", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Newsletter subscriber schema for validation
export const newsletterSubscriberSchema = createInsertSchema(newsletterSubscribers, {
  email: (schema) => schema.email("Must be a valid email address"),
});

// Export types
export type ContactMessage = typeof contactMessages.$inferSelect;
export type PortfolioItem = typeof portfolioItems.$inferSelect;
export type Testimonial = typeof testimonials.$inferSelect;
export type SliderImage = typeof sliderImages.$inferSelect;
export type NewsletterSubscriber = typeof newsletterSubscribers.$inferSelect;

// Export insert schemas as types
export type ContactMessageInsert = z.infer<typeof contactMessageSchema>;
export type PortfolioItemInsert = z.infer<typeof portfolioItemSchema>;
export type TestimonialInsert = z.infer<typeof testimonialSchema>;
export type SliderImageInsert = z.infer<typeof sliderImageSchema>;
export type NewsletterSubscriberInsert = z.infer<typeof newsletterSubscriberSchema>;
